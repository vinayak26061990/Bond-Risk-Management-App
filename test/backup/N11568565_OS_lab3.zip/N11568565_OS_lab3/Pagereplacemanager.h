/*
 * Pagereplacemanager.h
 *
 *  Created on: Apr 6, 2016
 *      Author: raghu
 */

#ifndef PAGEREPLACEMANAGER_H_
#define PAGEREPLACEMANAGER_H_
#include <iostream>
#include<unistd.h>
#include <iostream>
#include <fstream>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<vector>
#include<sstream>
#include <cctype>
#include<map>
using namespace std;

class choice
{
public:
	string page_algo,page_to_replace;
	int O,P,F,S;
	string input_file,rand_file;
	uint32_t phy_frame,vir_pg;
    choice();

};
class Instruction
{

public:
	uint32_t line_number,read_write_flag,page_number;
	Instruction();


};
class PageTable
{
public:
	uint32_t PRESENT:1;
	uint32_t  MODIFIED:1;
	uint32_t  REFERENCED:1;
	uint32_t  PAGEDOUT:1;
	uint32_t  FRAME:6;
	uint32_t  PAGE:6;
       PageTable(uint32_t a);

};
class Statistics
{
public:
uint64_t inst_count, unmaps, maps, ins, outs, zeros, totalcost;
Statistics();
void unmap();
void map();
void pageins();
void pageouts();
void pagezeros();
void computetotalcost();

};




class Pagereplacemanager {
public:

	PageTable** pt;
	PageTable** ft;
	vector <uint32_t> randomlist;
	Pagereplacemanager(){};
	Pagereplacemanager(choice);
	uint32_t instr_cnt;
    uint32_t used_frame_number;
    ifstream inputfile;
    choice c;
    Statistics s;
    uint32_t offset;
    void setrandomlist(vector<uint32_t>);
    Instruction* getnext();
	~Pagereplacemanager();
    void simulation();
    void printsummary();
	protected:
       uint32_t getrandom(uint32_t);
       virtual void pageaccess(uint32_t,uint32_t);
	virtual void pagein(uint32_t,uint32_t,uint32_t);
	virtual void pageout(uint32_t,uint32_t);
	virtual void replace(uint32_t,uint32_t);
};

#endif /* PAGEREPLACEMANAGER_H_ */
class RANDOM:public Pagereplacemanager
{
public:
	PageTable** pt_random;
	RANDOM(choice c):Pagereplacemanager(c)
	{
    	pt_random=(PageTable**)malloc(sizeof(PageTable*)*c.phy_frame);
    }
    ~RANDOM();
	void replace(uint32_t,uint32_t);
};

class FIFO:public Pagereplacemanager
{
public:
	vector<PageTable*> p;

	FIFO(choice d):Pagereplacemanager(d){};
    void pagein(uint32_t,uint32_t,uint32_t);
    void pageout(uint32_t,uint32_t);
    void replace(uint32_t,uint32_t);
};

class SECONDCHANCE:public FIFO
{
public:
	SECONDCHANCE(choice d):FIFO(d){};
	 void replace(uint32_t,uint32_t);
};

class LRU:public Pagereplacemanager
{

public:
  vector<PageTable*> lru_list;
  void replace(uint32_t,uint32_t);
  LRU(choice d):Pagereplacemanager(d){};
  void pageaccess(uint32_t,uint32_t);
  void pageout(uint32_t,uint32_t);
  void pagein(uint32_t,uint32_t,uint32_t);



};
class CLOCK:public Pagereplacemanager
{

uint32_t  hand;

public:
CLOCK(choice c):Pagereplacemanager(c)
{

hand=0;

}
void replace(uint32_t,uint32_t);



};


class AGING:public Pagereplacemanager
{

uint32_t *age;
uint32_t size;
PageTable *p;
PageTable **q;
public:
~AGING();
AGING(choice c):Pagereplacemanager(c)
{
p=NULL;
q=NULL;
if(c.page_to_replace=="V")
{
    q=pt;
    size=c.vir_pg;
}
else if(c.page_to_replace=="P")
{
q=ft;
size=c.phy_frame;

}
age=new uint32_t[size];
for(int i=0;i<size;i++)
{

age[i]=0;

}
};
void pageout(uint32_t,uint32_t);
void replace(uint32_t,uint32_t);
};












class NRU:public Pagereplacemanager
{
public:
uint32_t count,group0_count,group1_count,group2_count,group3_count,track_count;
PageTable** group[4];

void replace(uint32_t,uint32_t);
~NRU();
NRU(choice c):Pagereplacemanager(c)
{
	group0_count=group1_count=group2_count=group3_count=count=track_count=0;
    for(int j=0;j<4;j++)
    {
    	group[j]=(PageTable**)malloc(sizeof(PageTable*)* c.phy_frame);

    }

};


};
