//============================================================================
// Name        : mmu_final.cpp
// Author      : Vinayak
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<unistd.h>
#include <iostream>
#include <fstream>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<vector>
#include<sstream>
#include <cctype>
#include<map>
#include "Pagereplacemanager.h"
using namespace std;
string line;
uint32_t val=0;
vector<uint32_t> randomlist;

int main(int argc,char * argv[]) {
	choice ch;
       ifstream rfile;

		   	int c;
		    string option;
			while((c=getopt(argc,argv,"a:o:f:"))!=-1 )
			{
		     switch(c)
		     {

		     case 'a':
		    	       option=string(optarg);
		               if(option=="Y")
		               {
		            	   ch.page_algo="AGING";
		            	   ch.page_to_replace="V";
		               }
		               else if(option=="a")
		               {
		            	   ch.page_algo="AGING";
		            	   ch.page_to_replace="P";
		               }
		               else if(option=="X")
		               {
		            	   ch.page_algo="CLOCK";
		            	   ch.page_to_replace="V";
		               }
		               else if(option=="c")
		               {
		            	   ch.page_algo="CLOCK";
	            	       ch.page_to_replace="P";

		               }
		               else if(option=="s")
		               {
		            	   ch.page_algo="SECONDCHANCE";
	            	       ch.page_to_replace="P";

		               }
		               else if(option=="f")
		               {
		            	   ch.page_algo="FIFO";
	            	       ch.page_to_replace="P";

		               }
		               else if(option=="r")
		               {
		            	   ch.page_algo="RANDOM";
		            	   ch.page_to_replace="P";
		               }
		               else if(option=="l")
		               {
		            	   ch.page_algo="LRU";
		            	   ch.page_to_replace="P";
		               }

		               else if(option=="N")
		               {
		                   	   ch.page_algo="NRU";
		                   	   ch.page_to_replace="V";
		               }
                             else
                             {
                                cout<<"Unknown Replacement Algorithm: <"<<option<<">"<<endl;
                                exit(-1);
                             }

		    	       break;
		              case 'o': option=string(optarg);
		               for(int i=0;i<option.length();i++)
		               {
                         if(option[i]=='O')
                         {
                        	 ch.O=1;
                         }
                         else if(option[i]=='P')
                         {
                        	 ch.P=1;

                         }
                         else if(option[i]=='S')
                                                  {
                                                 	 ch.S=1;

                                                  }
                         else if(option[i]=='F')
                                                  {
                                                 	 ch.F=1;

                                                  }


		               }

		               break;
		     case 'f':
                       ch.phy_frame=atoi(optarg);
		    	       break;
		     case '?':
		    	       cout<<"Invalid input"<<endl;
		    	       break;
		     default:
		    	       exit(-1);
		     }

			}

			if((argc-optind)!=2)
			{
				cout<<"Two arguments needed"<<endl;
			}
			else
			{
	      	 ch.input_file=argv[optind];
	      	 ch.rand_file=argv[optind + 1];
			}

   /* cout<<"Paging Algo is "<<ch.page_algo<<" and the page to replace is "<<ch.page_to_replace<<endl;
    cout<<"OPFS is "<<ch.O<<" "<<ch.P<<" "<<ch.F<<" "<<ch.S<<endl;
    cout<<"Number of Physical frame "<<ch.phy_frame<<endl;
    cout<<"Number of Virtual Page is "<<ch.vir_pg<<endl;
    cout<<"Input file is "<<ch.input_file<<endl;
    cout<<"RandFile is "<<ch.rand_file<<endl;*/
    if(ch.rand_file!="")
    	{rfile.open(ch.rand_file.c_str());
        if(rfile.is_open())
        {
        	getline(rfile,line);
            while(getline(rfile,line)!=NULL)
            {
              istringstream(line)>>val;
              randomlist.push_back(val);

            }

        
        rfile.close();
        }
        else
        {
           cout<<"Error opening random file"<<endl;
        }
    	}
    /*int count=0;
    for(int i=0;i<randomlist.size();i++)
    {
        count=count+1;
        if(count<=9)
        {
    	cout<<"entry "<<i<<" is "<<randomlist[i]<<endl;
        }
        if(count==10000)
        {

        	cout<<"The last entry is "<<randomlist[i]<<endl;

        }
    }
   cout<<"hii"<<endl;
    cout<<"pagealgo is "<<ch.page_algo<<endl; */
    Pagereplacemanager *p;

    if(ch.page_algo=="FIFO")
    {
    	p=new FIFO(ch);

    }
    else if(ch.page_algo=="SECONDCHANCE")
    {
    	p=new SECONDCHANCE(ch);

    }
    else if(ch.page_algo=="RANDOM")
       {
       	p=new RANDOM(ch);

       }
    else if(ch.page_algo=="LRU")
          {
          	p=new LRU(ch);

          }
    else if(ch.page_algo=="NRU")
    {
            	p=new NRU(ch);

    }
    else if(ch.page_algo=="CLOCK")
    {

    	       p=new CLOCK(ch);

    }
    else if(ch.page_algo=="AGING")
      {

      	       p=new AGING(ch);

      }
    //cout<<"Algo is "<<ch.page_algo<<endl;
    //Pagereplacemanager p(ch);

    //Instruction *a=p->getnext();
   // cout<<"Index , flag , page number is "<<a->index<<" "<<a->read_write_flag<<" "<<a->page_number<<endl;
    p->setrandomlist(randomlist);
    p->simulation();
    delete p;
    return 0;
}
