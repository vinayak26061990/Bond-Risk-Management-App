/*
 * Pagereplacemanager.cpp
 *
 *  Created on: Apr 6, 2016
 *      Author: raghu
 */
#define UINT32_MAX  ((uint32_t)-1)

#include "Pagereplacemanager.h"
RANDOM::~RANDOM()
{
free(pt_random);
}
AGING::~AGING()
{
free(age);
}
Pagereplacemanager::~Pagereplacemanager()
{
if(ft!=NULL)
{
free(ft);
}
if(pt!=NULL)
{
free(pt);
}
}
	void RANDOM::replace(uint32_t ins,uint32_t page)
	{   uint32_t index=0;uint32_t rnd;
		for(int i=0;i<c.phy_frame;i++)
		{
			if(ft[i]->PRESENT==1)
			{
				pt_random[index]=ft[i];
				index=index+1;

			}


		}

      rnd=getrandom(index);
      pageout(ins,pt_random[rnd]->FRAME);
      pagein(ins,pt_random[rnd]->FRAME,page);


	}

void SECONDCHANCE::replace(uint32_t ins,uint32_t page)
{
	PageTable *pt_second;
	while(1)
	{

		pt_second=p.front();
		if(pt_second->REFERENCED!=1)
		{
			break;

		}
		else
		{

			pt_second->REFERENCED=0;
			p.erase(p.begin());
			p.push_back(pt_second);

		}
	}
	pageout(ins,pt_second->FRAME);
	pagein(ins,pt_second->FRAME,page);

}


void Pagereplacemanager::pageaccess(uint32_t ins,uint32_t frame)
{
	s.computetotalcost();


}

void Pagereplacemanager::printsummary()
{
	printf("SUM %d U=%d M=%d I=%d O=%d Z=%d ===> %llu\n",s.inst_count, s.unmaps, s.maps, s.ins, s.outs, s.zeros, s.totalcost);
}


Statistics::Statistics()
{
	inst_count=unmaps=maps=ins=outs=zeros=totalcost=0;
}

void Statistics::unmap()
{
unmaps=unmaps+1;
totalcost=totalcost+400;
}
void Statistics::map()
{
	maps=maps+1;
	totalcost=totalcost+400;
}
void Statistics::pageins()
{
	ins=ins+1;
	totalcost=totalcost+3000;


}
void Statistics::pageouts()
{
	outs=outs+1;
	totalcost=totalcost+3000;
}

void Statistics::pagezeros()
{
	zeros=zeros+1;
	totalcost=totalcost+150;
}
void Statistics::computetotalcost()
{
	totalcost=totalcost+1;
	inst_count=inst_count+1;
}







choice::choice()
{   page_to_replace="P";
	    page_algo="LRU";
    	phy_frame=32;vir_pg=64;
    	O=P=F=S=0;
    	input_file=rand_file="";


	}
void Pagereplacemanager::setrandomlist(vector<uint32_t> list)
{
	randomlist=list;
}
void Pagereplacemanager::simulation()
{
	string line;
	inputfile.open(c.input_file.c_str());

	if(!inputfile.is_open())
	{
		cout<<"Error opening the input file"<<endl;
	    exit(-1);
	}

	PageTable *p=NULL;
	Instruction *a=getnext();
   // cout<<"Got Instruction"<<endl;
	while(a!=NULL)
	{

		if(c.O==1)
		{

			printf("==> inst: %d %d\n", a->read_write_flag, a->page_number);

		}
        p = pt[a->page_number];
        //cout<<"Object is"<<p<<endl;
        if(p->PRESENT==0)
        {
        	if(used_frame_number<c.phy_frame)
        	{
        		pagein(a->line_number,used_frame_number++,a->page_number);



        	}
        	else
        	{
                //cout<<"Number of frame filled is"<<used_frame_number<<endl;
                //cout<<"Page number is"<<a->page_number<<endl;
        		replace(a->line_number,a->page_number);

        	}

        }

        pageaccess(a->line_number,p->FRAME);

        p->REFERENCED=1;
        if(a->read_write_flag==1)
        {

        	p->MODIFIED=1;

        }
        delete a;
        a=getnext();

	}


	if(c.P==1)
	{
		for(int i=0;i<c.vir_pg;i++)
				{
                   if(pt[i]->PRESENT==1)
                   {

                       printf("%d:%c%c%c ", pt[i]->PAGE, pt[i]->REFERENCED?'R':'-', pt[i]->MODIFIED?'M':'-', pt[i]->PAGEDOUT?'S':'-');


                   }
                   else
                   {
                	   if(pt[i]->PAGEDOUT==1)
                	   {
                		   printf("# ");
                	   }
                	   else
                	   {

                		   printf("* ");
                	   }

                   }
				}


       	cout<<endl;

	}

	if(c.F==1)
	{
		for(int j=0;j<c.phy_frame;j++)
		{
			if(ft[j]!=NULL)
			{
				printf("%d ",ft[j]->PAGE);

			}
			else
			{

				printf("* ");
			}


		}
       	cout<<endl;

	}
    if(c.S==1)
    {
	printsummary();
    }
	inputfile.close();

}
 void Pagereplacemanager::replace(uint32_t ind,uint32_t page){//pass
	}

 void Pagereplacemanager::pageout(uint32_t ind,uint32_t frame)
{
	if(ft[frame]==NULL)
	{
		cout<<"Cannot remove empty frame"<<endl;
		exit(-1);

	}
	else
	{
		PageTable *p=ft[frame];


		if(c.O==1)
		{
			printf("%d: UNMAP  %2d  %2d\n", ind, p->PAGE, p->FRAME);


		}
		s.unmap();

		if(p->MODIFIED==1)
		{
			p->MODIFIED=0;
			p->PAGEDOUT=1;

			if(c.O==1)
		{
			printf("%d: OUT    %2d  %2d\n", ind, p->PAGE, p->FRAME);

		}
			s.pageouts();

		}
		ft[frame]=NULL;
		p->PRESENT=0;



	}



}

 void Pagereplacemanager::pagein(uint32_t ind,uint32_t frame,uint32_t page)
{
if(ft[frame]!=NULL)
{

	cout<<"The frame already is used"<<endl;
	exit(-1);
}
else
{
PageTable *p=pt[page];
p->FRAME=frame;


if(p->PAGEDOUT==1)
{
	if(c.O==1)
	{
		printf("%d: IN     %2d  %2d\n", ind, p->PAGE, p->FRAME);
	}
    s.pageins();

}
	else
	{
		if(c.O==1)
			{
				printf("%d: ZERO       %2d\n", ind, p->FRAME);
			}
	    s.pagezeros();

	}
    if(c.O==1)
    {
    	printf("%d: MAP    %2d  %2d\n", ind, p->PAGE, p->FRAME);
    }
    s.map();

    p->PRESENT=1;
    ft[frame]=p;
}


}



void FIFO::pageout(uint32_t in,uint32_t frame)
{
	//cout<<"calling fifo pageout"<<endl;
	Pagereplacemanager::pageout(in,frame);
	p.erase(p.begin());


}
void FIFO::pagein(uint32_t in,uint32_t frame,uint32_t page)
{
	//cout<<"calling fifo pagein"<<endl;
	Pagereplacemanager::pagein(in,frame,page);
	p.push_back(pt[page]);

}
void FIFO::replace(uint32_t in,uint32_t page)
{
	//cout<<"calling fifo replace"<<endl;
   //cout<<"Frame to be replaced is "<<p.front()->FRAME<<endl;
   PageTable *r=p.front();
   pageout(in,r->FRAME);
   pagein(in,r->FRAME,page);
}


Pagereplacemanager::Pagereplacemanager(choice a)
{   pt=ft=NULL;
	this->c=a;

    offset=instr_cnt=used_frame_number=0;
    pt=(PageTable**)malloc(sizeof(PageTable*)*c.vir_pg);
	for(int i=0;i<c.vir_pg;i++)
	{
		pt[i]=new PageTable(i);

	}
    ft=(PageTable**)malloc(sizeof(PageTable*)*c.phy_frame);

	for(int i=0;i<c.phy_frame;i++)
	{
		ft[i]=NULL;

	}

}
uint32_t Pagereplacemanager::getrandom(uint32_t length)
{
uint32_t a=randomlist[offset]%length;
offset=(offset+1)%randomlist.size();
return a;

}
Instruction *Pagereplacemanager::getnext()
{
	Instruction *ins=NULL;
    string str;
while(getline(inputfile,str))
{
    //char buf[100];
    //strcpy(buf,str.c_str());
	//if(buf[0]!='#')
	if(str.at(0)!='#')
    {   ins=new Instruction();
       // cout<<"line is "<<str<<endl;
        istringstream s(str);
        ins->line_number=instr_cnt;
        s >> ins->read_write_flag >>ins->page_number;
       // sscanf(str.c_str(),"%SCNd32%SCNd32",&ins.read_write_flag,&ins.page_number);
        //cout<<"Inside the getnext flag is "<<ins->read_write_flag<<endl;
        //cout<<"Page number is "<<ins->page_number<<endl;
        instr_cnt++;
        break;
	}


}


return ins;
}



Instruction::Instruction()
{
	line_number=read_write_flag=page_number=0;
}
PageTable::PageTable(uint32_t a)
{
	FRAME=PRESENT=MODIFIED=REFERENCED=PAGEDOUT=0;
    this->PAGE=a;
}




void LRU::pageaccess(uint32_t ins,uint32_t frame)
{
Pagereplacemanager::pageaccess(ins,frame);
PageTable* p1=NULL;
for(int i=0;i<lru_list.size();i++)
{
if(lru_list[i]->FRAME==frame)
{
	p1=lru_list[i];
	lru_list.erase(lru_list.begin()+i);
    break;
}
}
if(p1!=NULL)
{
	lru_list.insert(lru_list.begin(),p1);

}


}
void LRU::pagein(uint32_t ins,uint32_t frame,uint32_t page)
{
	Pagereplacemanager::pagein(ins,frame,page);
    lru_list.insert(lru_list.begin(),pt[page]);

}
void LRU::pageout(uint32_t ins,uint32_t frame)
{
	Pagereplacemanager::pageout(ins,frame);
    lru_list.pop_back();

}
void LRU::replace(uint32_t ins,uint32_t page)
{
	PageTable *p=lru_list.back();
	pageout(ins,p->FRAME);
	pagein(ins,p->FRAME,page);


}
//void pageout(uint32_t,uint32_t)
void NRU::replace(uint32_t ins,uint32_t page)
{
	PageTable **t;uint32_t page_replace;int flag=0;
	t=pt;
       count=c.vir_pg;
	
	group0_count=group1_count=group2_count=group3_count=0;

	for(int i=0;i<count;i++)
	{
		PageTable *pg=t[i];
        if(pg->PRESENT==1)
        {
            if(pg->REFERENCED==0 && pg->MODIFIED==0)
        	{
             		group[0][group0_count]=pg;
        		group0_count=group0_count+1;

        	}
        	else if(pg->REFERENCED==0 && pg->MODIFIED==1)
        	{

        		group[1][group1_count]=pg;
        		group1_count=group1_count+1;

        	}
            else if(pg->REFERENCED==1 && pg->MODIFIED==0)
            	 {
                        group[2][group2_count]=pg;
            		    group2_count=group2_count+1;
             }
             else if(pg->REFERENCED==1 && pg->MODIFIED==1)
             {
            	 group[3][group3_count]=pg;
            	 group3_count=group3_count+1;


             }
        	}
}
	
	if(group0_count > 0 && flag==0)
	{
		page_replace=group[0][getrandom(group0_count)]->FRAME;
		flag=1;
	}
	else if(group1_count>0 && flag==0)
	{
		page_replace=group[1][getrandom(group1_count)]->FRAME;
		flag=1;
	}
	else if(group2_count>0 && flag==0)
		{
		  page_replace=group[2][getrandom(group2_count)]->FRAME;
		  flag=1;
		}
	else if(group3_count>0 && flag==0)
		{
		   page_replace=group[3][getrandom(group3_count)]->FRAME;
		   flag=1;
		}

track_count=track_count+1;
if(track_count==10)
{

for(int i=0;i<c.vir_pg;i++)
{
   if(pt[i]->PRESENT==1)
   {
	   pt[i]->REFERENCED=0;


   }

}
track_count=0;
}
pageout(ins,page_replace);
pagein(ins,page_replace,page);
}


NRU::~NRU()
{
free(group[0]);
free(group[1]);
free(group[2]);
free(group[3]);

}

void CLOCK::replace(uint32_t ins,uint32_t page)
{
PageTable* q;
int count;
PageTable** p;


if(c.page_to_replace=="P")
	{
      p=ft;
      count=c.phy_frame;
	}
	else if(c.page_to_replace=="V")
	{

      p=pt;
      count=c.vir_pg;
	}


while(1)
{

q=p[hand];
if(q->PRESENT==1 && q->REFERENCED==1)
{

	q->REFERENCED=0;
	hand=(hand+1)%count;
}
else if(q->PRESENT==0)
{
  hand=(hand+1)%count;
}
else
{
	  hand=(hand+1)%count;
      break;
}
}
pageout(ins,q->FRAME);
pagein(ins,q->FRAME,page);
}

void AGING::replace(uint32_t ins,uint32_t page)
{

uint32_t minimum=UINT32_MAX;


for (int i=0;i<size;i++)
{
if(q[i]->PRESENT==1 && q[i]!=NULL)
{
   age[i]=(age[i]>>1);
   if(q[i]->REFERENCED==1)
   {
	   age[i]=age[i]|((unsigned int)1 << 31);
	   q[i]->REFERENCED=0;

   }

}
}

for(int i=0;i<size;i++)
{
	if(q[i]->PRESENT==1 && q[i]!=NULL)
	{
       if(minimum > age[i])
       {   p=q[i];
    	   minimum=age[i];


       }
	}
	}

pageout(ins,p->FRAME);
pagein(ins,p->FRAME,page);

}


void AGING::pageout(uint32_t ins,uint32_t frame)
{
if(c.page_to_replace=="P")
{
age[frame]=0;
}
else if(c.page_to_replace=="V")

{
PageTable *pe=ft[frame];
age[pe->PAGE]=0;
}
Pagereplacemanager::pageout(ins,frame);
}
